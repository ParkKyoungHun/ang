export class UserHis {
    userNo:number;
    userData:string;
    constructor(values: Object = {}) {
      Object.assign(this, values);
    }
}
